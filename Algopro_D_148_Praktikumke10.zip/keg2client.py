
import socket

hostname = 'localhost'
pesan = ''
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((hostname, 50004))
print "Program komunikasi tentang server"
while pesan.lower() != 'quit':
    pesan = raw_input('command: ')
    s.send(pesan)
    if pesan.lower() == 'quit':
        s.close()
        break
    if pesan.lower() != 'quit':
        response = s.recv(1024)
        print 'response:', response  
s.close()
  
