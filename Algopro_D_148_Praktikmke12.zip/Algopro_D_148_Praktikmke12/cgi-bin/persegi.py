a=5

def hitung_persegi(s=0):
    return (s*s)
print "<!DOCTYPE html>"
print
print """<html>
	<head>
		<title>Hey Ho!</title>
		<style>
		body, table {
			font-family: arial;
			font-weight: bold;
		}
		.judul {
			font-size: 2rem;
			margin: 0;
		}
		img {
			padding-right: 1rem;
		}
		</style>
	</head>"""
	
print """<body>
		<img src="../persegi.png" style="width:200px;float:left;">
		<p class="judul">Data Bangun<p>"""


print                   "<table>"
print			"""<tr>
				<td>Nama Bangun</td>
				<td>:</td>
				<td>Persegi</td>
			</tr>

			<tr>
				<td>Dimensi(2D/3D)</td>
				<td>:</td>
				<td>2D</td>
			</tr>

			<tr>
				<td>Rumus Luas</td>
				<td>:</td>
				<td> s * s </td>
			</tr>"""

print			"""<tr>
				<td>parameter</td>
				<td>:</td>"""
print				"<td>"
print (a)
print                           "</td>"
print			"</tr>"

print			"<tr>"
print				"""<td>luas</td>
				<td>:</td>"""
print				"<td>"
print hitung_persegi(a)
print                           "</td>"
print			"</tr>"

print		"</table>"
		
print	"""</body></html>"""
