#PRAKTIKUM 9
#Dhimas Muhammad Ilham
#L200180148

#Kegiatan1&2

berkas = open("L200180148.txt", "w")
berkas.write("L200180148 \n")
berkas.write("06/11/2000 \n")
berkas.write("Sragen \n")
berkas.write("Dhimas Muhammad Ilham \n")
berkas.close()

d = open ("L200180148.txt", "r")
NIM = d.readline()
TL = d.readline()
KL = d.readline()
Nama = d.readline()
print ("a.", Nama)
print ("b.", KL, TL)
print ("c.", NIM)

#Kegiatan3

import shelve
a = open ("L200180148.txt", "r")
NIM = a.readline()
TL = a.readline()
KL = a.readline()
Nama = a.readline()
a.close()

a=shelve.open("dhims")
a['b'] = [NIM, KL, TL, Nama]
a.close()

#Kegiatan4

a=shelve.open("dhims")
print (a['b'])
print (a['b'][0])
print (a['b'][1])
print (a['b'][2])
