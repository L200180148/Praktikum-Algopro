##Nama = Dhimas Muhammad Ilham
##NIM  = L200180148
##Kelas= D / Praktikum Algopro

#Kegiatan1
g={'nim':'L200180148','nama':'Dhimas Muhammad Ilham','alamat':'Sragen','status':'Mahasiswa','tanggallahir':'06-11-2000','hobbi':'Berenang','tinggibadan':'168cm','k':'TerimaKasih'}
def nim():
    print ('NIM:',g['nim'])
def nama():
    print ('Nama:',g['nama'])
def alamat():
    print ('Alamat:',g['alamat'])
def status():
    print ('Status:',g['status'])
def tanggallahir():
    print ('TanggalLahir:',g['tanggallahir'])
def hobbi():
    print ('Hobbi:',g['hobbi'])
def tinggibadan():
    print ('TinggiBadan:',g['tinggibadan'])
def k():
    "keluar"
    print ('Terima Kasih')
def pilihan():
    print ('pilihan yang tersedia:')
    print ('a menampilkan bantuan ini')
    print ('b menampilkan nama')
    print ('c menampilkan NIM')
    print ('d menampilkan tanggallahir')
    print ('e menampilkan alamat')
    print ('f menampilkan status')
    print ('g menampilkan hobbi')
    print ('h menampilkan tinggibadan')
    print ('k keluar')

pilihan()

a=input('pilihan saudara:')
while a != 'z':
    if a == "a":
        print ('pilihlah daftar pilihan yang telah tersedia')
        a=input('pilihan saudara:')
    elif a == "b":
        nama()
        a=input('pilihan saudara:')
    elif a == "c":
        nim()
        a=input('pilihan saudara:')
    elif a == "d":
        tanggallahir()
        a=input('pilihan saudara:')
    elif a == "e":
        alamat()
        a=input('pilihan saudara:')
    elif a == "f":
        status()
        a=input('pilihan saudara:')
    elif a == "g":
        hobbi()
        a=input('pilihan saudara:')
    elif a == "h":
        tinggibadan()
        a=input('pilihan saudara:')
    elif a == "k":
        k()
        break
    else:
        print ('perintah tidak dikenal')
        a=input('pilihan saudara:')

#Kegiatan2
def KonversiSuhu(c = 0, f = 32):
    "konversi suhu celcius dan fahrenheit"
    if c != 0 and f == 32:
        f=float((c*9/5)+32)
        print('Suhu', c, 'celcius setara dengan', f, 'fahrenheit')
    elif f != 32 and c == 0:
        c=float((f-32)*5/9)
        print('Suhu', f, 'fahrenheit setara dengan', c, 'celcius')
    else:
        f=float((c*9/5)+32)
        print('Suhu', c, 'celcius setara dengan', f, 'fahrenheit')
