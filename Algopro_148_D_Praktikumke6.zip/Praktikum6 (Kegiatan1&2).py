## Kegiatan 1 Program Identitas Diri. Dibuat Oleh Dhimas L200180148
Nama = 'Dhimas Muhammad Ilham'
Alamat = 'Mojodoyong, Kedawung, Sragen'
Umur = '17'
Jenis_Kelamin = 'Laki-Laki'
TTL = 'Sragen, 6 November 2000'
NIM = 'L200180148'
Prodi = 'Informatika'
Fakultas = 'Fakultas Komunikasi dan Informatika'
Tinggal = 'Wisma Pandawa'
Hobi = 'Berenang'

## Kegiatan 2
## Program Akun
## Dibuat Oleh Dhimas L200180148
Nama = 'Dhimas Muhammad Ilham'
Alamat = 'Mojodoyong, Kedawung, Sragen'
Umur = '17'
Jenis_Kelamin = 'Laki-Laki'
TTL = 'Sragen, 6 November 2000'
NIM = 'L200180148'
Prodi = 'Informatika'
Fakultas = 'Fakultas Komunikasi dan Informatika'
Tinggal = 'Wisma Pandawa'
Hobi = 'Berenang'
Nama_Singkat = Nama[0] + '.' + Nama[7] + '.' + Nama[16: ]
Username = Nama[0] + TTL[8] + TTL[19: ]
Password = Nama[0:3] + NIM[7: ]
