Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> Nama = 'Dhimas Muhammad Ilham'
>>> NIM = 148
>>> Tinggi = 1.69
>>> Berat = 105
>>> TahunLahir = 2000
>>> Aku = (TahunLahir, Berat, Tinggi, NIM, Nama)
>>> Data = [TahunLahir, Berat, Tinggi, NIM, Nama]
>>> type(Aku)
<class 'tuple'>
>>> ## 'Aku' merupakan data tuple
>>> Aku[0]
2000
>>> ## Indeks pertama/[0] dari 'Aku' yaitu TahunLahir (2000).
>>> a = NIM % 4; Aku[a]
2000
>>> ## Sisa pembagian dari NIM(148) dibagi 4 yaitu 0. kemudian Aku[0] sama dengan 2000
>>> type(Aku[a])
<class 'int'>
>>> ## tipe dari Aku[a] merupakan tipe integer, karena berisi bilangan bulat, yaitu 2000
>>> Aku[a:4]
(2000, 105, 1.69, 148)
>>> ## hasil dari Aku[a:4] yaitu 2000, 105, 1.69, 148 (sesuai data diatas)
>>> type(Aku[4])
<class 'str'>
>>> ## Aku[4] merupakan tipe string, yaitu 'Dhimas Muhammad Ilham'
>>> Aku[0] = 'ok'
Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    Aku[0] = 'ok'
TypeError: 'tuple' object does not support item assignment
>>> ## tipe error, saya tidak tahu kenapa error
>>> Aku[0] = 'ok' ; Aku
Traceback (most recent call last):
  File "<pyshell#21>", line 1, in <module>
    Aku[0] = 'ok' ; Aku
TypeError: 'tuple' object does not support item assignment
>>> type(Data)
<class 'list'>
>>> ## Data merupakan tipe list, ditandai dengan tanda []
>>> type(Data[4])
<class 'str'>
>>> ## Data[4] merupakan tipe string, karena berisi huruf.
>>> Data[4][5]
's'
>>> ## 's' merupakan huruf ke 5 dari Nama (dihitung dari angka 0)
>>> Data[4][a:6]
'Dhimas'
>>> ## Data dari nama, diambil huruf dari ke 0-6 hasilnya 'Dhimas'.
>>> Data[0] = 'ok'; Data
['ok', 105, 1.69, 148, 'Dhimas Muhammad Ilham']
>>> ## Isi dari data ke 0 diganti dengan ok, hasilnya seperti diatas.
>>> Data[-a]
'ok'
>>> ## karena sama dengan 0, jadi diambil list yg ke 0, karena -0 itu ga ada.
>>> range(a)
range(0, 0)
>>> ## karena a sama dengan 0, dari rangenya 0, 0.
>>> 
