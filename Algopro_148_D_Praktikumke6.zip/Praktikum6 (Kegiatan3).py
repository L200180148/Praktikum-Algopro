Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
============== RESTART: D:\AlgoPro\Praktikum6 (Kegiatan1&2).py ==============
>>> ## Kegiatan 1 Program Identitas Diri
>>> Nama
'Dhimas Muhammad Ilham'
>>> Alamat
'Mojodoyong, Kedawung, Sragen'
>>> Umur
'17'
>>> Jenis_Kelamin
'Laki-Laki'
>>> TTL
'Sragen, 6 November 2000'
>>> NIM
'L200180148'
>>> Prodi
'Informatika'
>>> Fakultas
'Fakultas Komunikasi dan Informatika'
>>> Tinggal
'Wisma Pandawa'
>>> Hobi
'Berenang'
>>> 
>>> 
============== RESTART: D:\AlgoPro\Praktikum6 (Kegiatan1&2).py ==============
>>> ##Kegiatan 2 Program Akun
>>> Nama_Singkat
'D.M.Ilham'
>>> Username
'D62000'
>>> Password
'Dhi148'
>>> 
>>> 
>>> ## Kegiatan 3 Operator
>>> Nama = 'Dhimas Muhammad Ilham'
>>> NIM = 'L200180148'
>>> X = '1' + NIM[7: ]
>>> a = int(X)
>>> b = len(Nama)
>>> type(a)
<class 'int'>
>>> ## 'a' merupakan data integer, yaitu bilangan bulat.
>>> type(b)
<class 'int'>
>>> ## 'b' merupakan interger, yaitu bilangan bulat.
>>> a / b
54.666666666666664
>>> ## a (1148) dibagi b (21) hasilnya 54.66666666666664 (dalam bilangan desimal/float.
>>> a // b
54
>>> ## a dibagi b hasilnya 54 (dalam bilanganbulat/integer).
>>> 10 * (a - 999)
1490
>>> ## a(1148) dikurangan 999, kemudian dikali 10, hasilnya 1490.
>>> b ** 2
441
>>> ## b(21) dipangkatkan 2 hasilnya 441.
>>> a % b
14
>>> ## sisa pembagian dari a dibagi b yaitu 14
>>> c = 12.5
>>> ## menyimpan data 12.5 di var c
>>> type(c)
<class 'float'>
>>> ## c merupakan biangan desimal/float.
>>> a / c
91.84
>>> ## a dibagi c hasilnya 91.84 dalam bilangan desimal/float.
>>> a // c
91.0
>>> ## a dibagi c hasilnya 91 dalam bilangan bulat/integer.
>>> a % c
10.5
>>> ## sisa pembagian dari a dibagi c yaitu 10.5 dalam float.
>>> c > b
False
>>> ## c tidak lebih besar dari b, maka jawabannya 'false'/salah
>>> type(c > b)
<class 'bool'>
>>> ## c > b merupakan type boolean,
>>> a > b and b > c
True
>>> ## a lebih besar dari b, dan b lebih besar dari c, maka jawabannya benar/'True'
>>> a > 1100 or b < 10
True
>>> ## a lebih besar dari 1100, atau b kurang dari 10.
>>> 
>>> 
>>> 
>>> ## Kegiatan 4 Tipe Data
>>> 
