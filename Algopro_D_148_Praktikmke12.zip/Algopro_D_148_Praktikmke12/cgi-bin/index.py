print "<!DOCTYPE html>"
print
print """<html>
	<head>
		<title>Hey Ho!</title>
		<style>
		body, table {
			font-family: arial;
			font-weight: bold;
		}
		.judul {
			font-size: 2rem;
			margin: 0;
		}
		img {
			padding-right: 1rem;
		}
		</style>
	</head>"""
	
print """<body>
		<img src="../dhim.jpg" style="width:250px;float:left;">
		<p class="judul">Data Diri<p>
		<table>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td>Dhimas Muhammad Ilham</td>
			</tr>
			<tr>
				<td>NIM</td>
				<td>:</td>
				<td>L200180148</td>
			</tr>
			<tr>
				<td>Prodi</td>
				<td>:</td>
				<td>Informatika</td>
			</tr>
			<tr>
				<td>Fakultas</td>
				<td>:</td>
				<td>FKI</td>
			</tr>
			<tr>
				<td>Status</td>
				<td>:</td>
				<td>Mahasiswa</td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td>Sragen</td>
			</tr>
			<tr>
				<td>Idola</td>
				<td>:</td>
				<td>Vitas</td>
			</tr>
		</table>
	</body>"""
print "</html>"
